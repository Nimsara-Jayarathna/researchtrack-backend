SE3112 ResearchTrack load testing - fixture for a dedicated project only.
